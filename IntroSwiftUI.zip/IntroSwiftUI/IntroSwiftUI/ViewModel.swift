//
//  ViewModel.swift
//  IntroSwiftUI
//
//  Created by Consultant on 3/30/22.
//

import Foundation
import SwiftUI

struct Course: Hashable, Codable {
    let title: String?
    let imageURL: String
    
    enum CodingKeys: String, CodingKey {
        case title
        case imageURL = "imageUrl"
    }
}

class ViewModel: ObservableObject {
    
    // Every time this array is updated the view is going to need to know its going to update itself
    @Published var courses: [Course] = []
    
    func fetch() {
        guard let url = URL(string: "https://api.spaceflightnewsapi.net/v3/articles") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self]
            data, _, error in
            guard let data = data, error == nil else {
                return
            }
            
            // Convert to JSON
            do {
                let courses = try JSONDecoder().decode([Course].self, from: data)
                DispatchQueue.main.async {
                    self?.courses = courses
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
}
