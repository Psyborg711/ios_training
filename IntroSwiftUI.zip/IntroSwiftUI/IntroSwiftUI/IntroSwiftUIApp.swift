//
//  IntroSwiftUIApp.swift
//  IntroSwiftUI
//
//  Created by Consultant on 3/30/22.
//

import SwiftUI

@main
struct IntroSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
