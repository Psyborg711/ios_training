//
//  SecondViewController.m
//  ObjCPractice
//
//  Created by Consultant on 3/17/22.
//

#import "SecondViewController.h"
#import "ViewController.h"


NSString *selectedCountry = @"nationState";

@interface SecondViewController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;


@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupConfiguration];
    NSLog(@"list of Countries");
    
    // Do any additional setup after loading the view.
}

-(void)setupConfiguration{
    self.title = @"List of Countries";
}

/*
    static list of countries array to populate tableview
 */
-(NSArray *)countriesList {
    
    NSArray *countriesList = [NSArray arrayWithObjects:@"Costa Rica", @"Peru", @"Mexico", @"Ireland", @"Germany", @"Australia", @"Chile", @"Spain", @"England", @"Netherlands", @"India", @"Switzerland", @"France", nil];
    return countriesList;
}

/*
 TableView Methods delegates set in storyboard
 */

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    get count of countries in countries list for number of cells
    return  self.countriesList.count;
}

-(UITableView *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:selectedCountry forIndexPath:indexPath];
    
    cell.textLabel.text = [self.countriesList objectAtIndex:indexPath.row];
    return  cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated: false];
    
    [self.navigationController popToRootViewControllerAnimated:true];
    
//    Update the Label
//    KVC
    self.firstVC.clickHereLabel.text = [self.countriesList objectAtIndex:indexPath.row];
//    delegation
//    [self.delegate addCountry:[self.countriesList objectAtIndex:indexPath.row]];
//    block closure
//    self.selectedCountry([self.countriesList objectAtIndex:indexPath.row]);
    
    self.selectedCountry([self.countriesList objectAtIndex:indexPath.row]);
}

-(void)getLastCountry:(void (^)(NSString * _Nonnull))selectedCountry{
    self.selectedCountry(self.countriesList.lastObject);
}

@end
