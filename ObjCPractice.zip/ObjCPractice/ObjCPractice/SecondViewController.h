//
//  SecondViewController.h
//  ObjCPractice
//
//  Created by Consultant on 3/17/22.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

NS_ASSUME_NONNULL_BEGIN

@protocol AddCountryDelegate <NSObject>

-(void)addCountry: (NSString *) countryName;

@end

@interface SecondViewController : UIViewController

@property (nonatomic, weak) id <AddCountryDelegate> delegate;

@property (nonatomic, weak) ViewController *firstVC;

@property (nonatomic, copy)void(^selectedCountry)(NSString *);

-(void)getLastCountry: (void(^)(NSString *))selectedCountry;

@end



NS_ASSUME_NONNULL_END
