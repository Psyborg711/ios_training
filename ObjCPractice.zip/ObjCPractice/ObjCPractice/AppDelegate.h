//
//  AppDelegate.h
//  ObjCPractice
//
//  Created by Consultant on 3/17/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

