//
//  ViewController.swift
//  codable2
//
//  Created by Consultant on 3/2/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var heroes = [Hero]()
    var indexNo: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        // Do any additional setup after loading the view.
    }

    func setupTableView() {
        fetchJson {
            self.tableView.reloadData()
        }
        tableView.delegate = self
        tableView.dataSource = self
    }
    /*
     a closure is said to escape a function when the closure is passed as an argument to the function, but is called after the function returns. escaping closures outlives the function it was passed into
     */

    func fetchJson(completed: @escaping () ->()){
        
        guard let url = URL(string: "https://api.opendota.com/api/heroStats") else { return }
        let session = URLSession.shared
        let task = session.dataTask(with: url) { data, response, error in
            guard error == nil else{
                print("Error: \(error?.localizedDescription ?? " Something strange")")
                return
            }
            guard let response = response as? HTTPURLResponse, (200...299).contains(response.statusCode) else {
                print("server error!")
                return
            }
            guard data != nil else{
                print("error: no data bub")
                return
            }
            
            do{
                // instead of first needing to serialize the json with JsonSerialization class associated functions we can instead let the instance of our array of heroes hold
                self.heroes = try JSONDecoder().decode([Hero].self, from: data!)
                
                DispatchQueue.main.async {
                    // here we call the closure to indicate this is where the result of the fetch should be
                    completed()
                }
            }
            catch{
                print("Error: \(error.localizedDescription)")
            }
        }
        task.resume()
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return heroes.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.textLabel?.text = heroes[indexPath.row].name.capitalized
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "detailSegue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        let destination = segue.destination as! detailViewController
        
            destination.hero = heroes[(tableView.indexPathForSelectedRow?.row)!]
        
            
    }
}

