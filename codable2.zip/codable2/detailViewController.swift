//
//  detailViewController.swift
//  codable2
//
//  Created by Consultant on 3/2/22.
//

import UIKit

class detailViewController: UIViewController {

    @IBOutlet weak var detailImg: UIImageView!
    @IBOutlet weak var nameDetail: UILabel!
    @IBOutlet weak var attckAttr: UILabel!
    @IBOutlet weak var primaryAttck: UILabel!
    @IBOutlet weak var leg: UILabel!
    
    var hero: Hero?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        nameDetail.text = hero?.name
        attckAttr.text = hero?.primaryAttribute
        primaryAttck.text = hero?.attackType
        leg.text = "\((hero?.legs)!)"
        let baseURL = "https://api.opendota.com" + (hero?.image)!
        let url = URL(string: baseURL)
        detailImg.getImage(from: url!)
        // Do any additional setup after loading the view.
    }
}


