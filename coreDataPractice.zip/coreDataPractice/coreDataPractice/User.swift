//
//  User.swift
//  coreDataPractice
//
//  Created by Consultant on 3/10/22.
//

import Foundation
import CoreData

//public class User: NSManagedObject {
//    @NSManaged var name: String
//    @NSManaged var age: Int16
//    @NSManaged var createdDate: Date
//}

public class User: NSManagedObject {
    @NSManaged var avatar: String
    @NSManaged var id: Int16
    @NSManaged var email: String
    @NSManaged var firstName: String
    @NSManaged var lastName: String
}
