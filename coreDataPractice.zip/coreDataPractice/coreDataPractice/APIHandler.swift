//
//  APIHandler.swift
//  coreDataPractice
//
//  Created by Consultant on 3/10/22.
//

import Foundation

class APIHandler{
    static let shared = APIHandler()
//    returning -> is the same as -> void
    
    func syncUsers(completion: @escaping(()-> ())){
        guard let url = URL(string: "https://reques.in/api/users") else {return}
        
        let session = URLSession.shared
        let task = session.dataTask(with: url, completionHandler: {data, response, error in
            do{
    //           let jsonResponse = try
    //            JSONSerialization.jsonObject(with: data!, options: []) as! Dictionary<String, Any>
    //            print(jsonResponse)
                let model = try JSONDecoder().decode(APIResponse<[UserServerModel]>.self, from: data!)
//                print(model)
                model.data.forEach {$0.store()}
                completion()
            }
            catch{
            print(error.localizedDescription)
            completion()
                                    }
        })
        task.resume()
    }
}

public struct APIResponse<T: Codable>: Codable {
    public let page: Int
    public let totalPages: Int
    public let total: Int
    public let perPage: Int
    public let data: T
    
    enum CodingKeys: String, CodingKey {
        case page = "page"
        case totalPages = "total_pages"
        case total = "total"
        case perPage = "per_page"
        case data = "data"
    }
}
