//
//  ViewController.swift
//  coreDataPractice
//
//  Created by Consultant on 3/10/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var ageTextField: UITextField!
    
    @IBOutlet weak var tableView: UITableView!
    
    let database = DatabaseHandler.shared
    var users: [User]? {
        didSet {
            /*
             with the didSet property observer the code below executes whenever a property has changed
             that means for us the array of User objects is updated we reload the tableview in real time
             https://nshipster.com/swift-property-observers/
             */
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
//            self.tableview.reloadData()
        }
    }
  
    override func viewDidLoad() {
        super.viewDidLoad()
        setupDelegates()
//        tableview.register(UserTableViewCell.self, forCellReuseIdentifier: "UserTableViewCell")
        tableView.tableFooterView = UIView(frame: .zero)
        view.layer.cornerRadius = 10
        tableView.layer.cornerRadius = 10
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //step 1.
//        let results = database.fetch(User.self)
        // step 2.
        users = database.fetch(User.self)
        //checking to see if we are saving to core data
//        print(results.map { $0.name })
    }
    
    override func viewDidAppear(_ animated: Bool) {
        APIHandler.shared.syncUsers { [weak self] in
            //
            self?.users = self?.database.fetch(User.self)
        }
    }

    @IBAction func saved(_ sender: Any) {
        //calling save to persist data
        save()
    }
    //MARK: - Helper Functions
    func setupDelegates() {
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    func save() {
        guard let user = database.add(User.self) else { return }
//        guard let name = nameTextField.text, let ageText = ageTextField.text, let age = Int16(ageText) else { return }
//        user.name = name
//        user.age = age
//        user.createdDate = Date()
//        users?.append(user)
//        database.save()
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        users?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "userTableViewCell") as! UserTableViewCell
//        cell = UITableViewCell(style: .value1, reuseIdentifier: "UserTableViewCell")
//        cell.layer.cornerRadius = 10
//        let entity = users?[indexPath.row]
        cell.user = users?[indexPath.row]
//        cell.textLabel?.text = "\((entity?.firstName)!) \((entity?.lastName)!)"
//        cell.detailTextLabel?.text = "\((entity?.email)!)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        switch editingStyle {
        case .insert:
            print("inserting...")
        case .delete:
            print("deleting...")
            guard let user = users?[indexPath.row] else { return }
            //Begins a series of method calls that insert, delete, or select rows and sections of the table view.
            tableView.beginUpdates()
            users?.remove(at: indexPath.row)
            //delte user from coredata
            database.delete(user)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            //Concludes a series of method calls that insert, delete, select, or reload rows and sections of the table view
            tableView.endUpdates()
        default:
            break
        }
    }
    
}

class UserTableViewCell: UITableViewCell {
    
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    
    var user: User? {
        didSet {
            setupCell()
        }
    }
    
    private func setupCell() {
        guard let user = user else { return }
        let url = URL(string: user.avatar)
        userImage.getImage(from: url!)
        nameLabel.text = "\((user.firstName)) \((user.lastName))"
        emailLabel.text = user.email
    }
    
    override func prepareForReuse() {
        userImage.image = nil
        nameLabel.text = nil
        emailLabel.text = nil
    }
    
}

extension UIImageView {
    func getImage(from url: URL, contentMode mode: ContentMode = .scaleAspectFit) {
        contentMode = mode
        let session = URLSession.shared
        let task = session.dataTask(with: url) { data, response, error in
            guard let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200 else { return }
            guard let mimeType = response?.mimeType, mimeType.hasPrefix("image") else { return }
            guard let data = data, error == nil else { return }
            guard let image = UIImage(data: data) else { return }
            
            DispatchQueue.main.async {
                self.image = image
            }
        }
        task.resume()
    }
}
