//
//  Pokedex.swift
//  PokedexEVM
//
//  Created by Consultant on 3/4/22.
//

import Foundation

struct Pokedex: Codable{
    let count:Int?
    let next:String?
    let previous:String?
    let results: [PokeDetailLink]
}

struct PokeDetailLink: Codable{
    let name:String?
    let url:String?
}
