//
//  DetailViewController.swift
//  MovieBD
//
//  Created by Consultant on 3/4/22.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var detailImg: UIImageView!
    @IBOutlet weak var detailTitle: UILabel!
    @IBOutlet weak var detailYear: UILabel!
    @IBOutlet weak var detailDescription: UILabel!
    
    
    var imagenPeli: String?
    var tituloPeli: String?
    var anoPeli: String?
    var descPeli: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string: "https://image.tmdb.org/t/p/original/\(imagenPeli ?? "")")!
        if let data = try? Data(contentsOf: url){
            detailImg.image = UIImage(data: data)
        }
        
        detailTitle.text = tituloPeli ?? "no titulo".capitalized
        detailYear.text = anoPeli ?? "no year"
        detailDescription.text = descPeli ?? " no description"
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonReturn(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
