//
//  ViewController.swift
//  MovieBD
//
//  Created by Consultant on 3/3/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var tableView: UITableView!
    var movie = [Movie]()
    var indexNo: Int = 0
    var isLoading = false
    var pageToLoad: Int = 1
    //var movies = MovieData()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        // Do any additional setup after loading the view.
        let tableViewLoadingCell = UINib(nibName: "LoadingCell", bundle: nil)
        self.tableView.register(tableViewLoadingCell, forCellReuseIdentifier: "loadingCellid")
    }

    func setupTableView(){
        fetchJson {
            self.tableView.reloadData()
            
        }
        tableView.delegate = self
        tableView.dataSource = self
    }
    func fetchJson(completed: @escaping () ->()){
        
        guard let url = URL(string: "https://api.themoviedb.org/3/movie/top_rated?api_key=e39a044c50038db38752a58b9be72dd1&language=en%20US&page=\(pageToLoad)") else { return }
        let session = URLSession.shared
        let task = session.dataTask(with: url) { data, response, error in
            guard error == nil else{
                print("Error: \(error?.localizedDescription ?? " Something strange")")
                return
            }
            guard let response = response as? HTTPURLResponse, (200...299).contains(response.statusCode) else {
                print("server error!")
                return
            }
            guard data != nil else{
                print("error: no data bub")
                return
            }
            
            do{
                // instead of first needing to serialize the json with JsonSerialization class associated functions we can instead let the instance of our array of heroes hold
                //self.movies = try JSONDecoder().decode([MovieData].self, from: data!)
                //print(data!)
                let decoder = JSONDecoder()
                    //decoder.keyDecodingStrategy = .convertFromSnakeCase
                let resultado = try decoder.decode(MovieData.self, from: data!)
                self.movie = resultado.results
                
                
                print(self.movie)
                
                DispatchQueue.main.async {
                    // here we call the closure to indicate this is where the result of the fetch should be
                    completed()
                }
            }
            catch{
                print("Error: \(error.localizedDescription)")
            }
        }
        task.resume()
    }
    


}
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return movie.count
        }
        else if section == 1{
            return 1
        }
        else{
            return 0
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
            cell.textLabel?.text = movie[indexPath.row].nombre
            cell.detailTextLabel?.text = "\(String(format: "%.2f", movie[indexPath.row].puntaje))"
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "loadingCellid", for: indexPath) as! LoadingCell
            cell.activityIndicator.startAnimating()
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            if indexPath.section == 0 {
                return 44 //Item Cell height
            } else {
                return 55 //Loading Cell height
            }
        }
    
    

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
            let offsetY = scrollView.contentOffset.y
            let contentHeight = scrollView.contentSize.height

            if (offsetY > contentHeight - scrollView.frame.height * 4) && !isLoading {
                loadMoreData()
            }
        }
    
    func loadMoreData() {
            if !self.isLoading {
                self.isLoading = true
                DispatchQueue.global().async {
                    // Fake background loading task for 2 seconds
                    sleep(2)
                    // Download more data here
                    self.pageToLoad += 1
                    self.fetchJson {
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                            self.isLoading = false
                    }
                    
                    }
                }
            }
        }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "movieSegue", sender: self)
        indexNo = indexPath.row
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        let destination = segue.destination as! DetailViewController
        
        destination.imagenPeli = movie[(tableView.indexPathForSelectedRow?.row)!].imagen
        destination.tituloPeli = movie[(tableView.indexPathForSelectedRow?.row)!].nombre
        destination.anoPeli = movie[(tableView.indexPathForSelectedRow?.row)!].fecha
        destination.descPeli = movie[(tableView.indexPathForSelectedRow?.row)!].descripcion
            
    }
    
}

