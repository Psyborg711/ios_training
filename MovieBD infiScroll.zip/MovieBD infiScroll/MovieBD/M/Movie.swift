//
//  Movie.swift
//  MovieBD
//
//  Created by Consultant on 3/3/22.
//

import Foundation

//struct Movie:Codable {
//    let nombre:String
//    let puntaje:String
//    let fecha:String
//    let descripcion:String
//    let imagen:String
//    
//    enum CodingKeys: String, CodingKey{
//        case nombre = "original_title"
//        case puntaje = "vote_average"
//        case fecha = "release_date"
//        case descripcion = "overview"
//        case imagen = "poster_path"
//    }
//}
