//
//  MovieData.swift
//  MovieBD
//
//  Created by Consultant on 3/3/22.
//

import Foundation

struct MovieData: Decodable{
    let page: Int
    let results: [Movie]
    let total_pages: Int
    let total_results: Int
}

struct Movie:Decodable {
    let nombre:String
    let puntaje:Double
    let fecha:String
    let descripcion:String
    let imagen:String
    
    enum CodingKeys: String, CodingKey{
        case nombre = "original_title"
        case puntaje = "vote_average"
        case fecha = "release_date"
        case descripcion = "overview"
        case imagen = "poster_path"
    }
}
