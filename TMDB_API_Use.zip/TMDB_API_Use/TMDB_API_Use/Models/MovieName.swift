//
//  MovieName.swift
//  TMDB_API_Use
//
//  Created by Consultant on 3/3/22.
//

import Foundation

struct Raw: Codable
{
    let page: Int
    let results: [Movie]
    let total_pages: Int
    let total_results: Int
}

struct Movie: Codable
{
    let original_title: String
    let vote_average: Double
    let poster_path: String?
    let release_date: String
    let overview: String
    
    //enum CodingKeys: String, CodingKey {
        //case name = "localized_name"
        //case primaryAttribute = "primary_attr"
       // case attackType = "attack_type"
       // case legs = "legs"
       // case image = "img"
    //}
}


