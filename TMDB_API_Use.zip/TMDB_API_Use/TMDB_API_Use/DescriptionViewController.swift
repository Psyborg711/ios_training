//
//  DescriptionViewController.swift
//  TMDB_API_Use
//
//  Created by Consultant on 3/4/22.
//

import UIKit

class DescriptionViewController: UIViewController {
    
    @IBOutlet weak var imageview: UIImageView?
    @IBOutlet weak var labelYear: UILabel?
    @IBOutlet weak var labelDesc: UILabel?

    var movies:Movie?
    //var imagePath: String
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureLabels()
        configureImage()
    }
    
    func configureLabels(){
        labelYear?.text = movies?.original_title
        labelDesc?.text = movies?.overview
    }
    
    func configureImage(){
        let imageurl = URL(string: "https://image.tmdb.org/t/p/original" + "\(movies?.poster_path ?? "/")")
        print (imageurl!)
        //let imgURL = URL(string: imageurl)
        //imageview.getImage(from: imgURL!)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
