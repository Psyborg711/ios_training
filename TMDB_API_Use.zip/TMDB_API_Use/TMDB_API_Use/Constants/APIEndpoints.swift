//
//  APIEndpoints.swift
//  TMDB_API_Use
//
//  Created by Consultant on 3/3/22.
//

import Foundation

struct APIEndpoints {
    static let films = URL(string: "https://api.themoviedb.org/3/movie/top_rated?api_key=e39a044c50038db38752a58b9be72dd1&language=en-US&page=1")
}
