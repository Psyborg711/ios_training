//
//  ViewController.swift
//  TMDB_API_Use
//
//  Created by Consultant on 3/3/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableview: UITableView!
    
    var film = [Movie]()

    override func viewDidLoad() {
        
        super.viewDidLoad()
    
        setupDelegates()
        fetchMovie()
    }
    
    func setupDelegates(){
        tableview.delegate = self
        tableview.dataSource = self
    }
    
    
    
    func fetchMovie() {
        URLSession.shared.getRequest(url: APIEndpoints.films, decoding: Raw.self) { [weak self] result in
            switch result {
            case.success (let raw):
                self?.film = raw.results
                DispatchQueue.main.async {
                    self?.tableview.reloadData()
                }
            case.failure(let error):
                print(error)
            }
        }
        print(film)
    }
    

}

extension ViewController: UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return film.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = film[indexPath.row].original_title.capitalized
        cell.detailTextLabel?.text = String(film[indexPath.row].vote_average)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "segue1", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as?
            DescriptionViewController {
            destination.movies =    film[(tableview.indexPathForSelectedRow?.row)!]
        }
    }
}



