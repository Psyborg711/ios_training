//
//  ViewController.swift
//  IntroToMapKit
//
//  Created by Consultant on 3/22/22.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    private let locationManager = CLLocationManager()
    private let userRadiusInMeters: Double = 1000
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        checkAuthStatus()
        
    }
    
    // Core Location framework: Core location providesa services that determin a device's geographic location, altitude and orientation or its position relative to a nearby iBeacon device.  The framework gather data using all available components on the device, including the wi-fi, gps, bluetooth, magnometer, barometer and cellular hardware.  at https://developer.apple.com/documentation/corelocation also https://developer.apple.com/videos/play/wwdc2020/10660
    
    
    private func setupLocationServices() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }

    private func checkAuthStatus() {
        switch locationManager.authorizationStatus {
        case .restricted, .denied:
            break
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
            // CThe like Delegates can also set show user location in the interface builder
            mapView.showsUserLocation = true
        case .authorizedAlways:
            mapView.showsUserLocation = true
            grokUserLocation()
            locationManager.startUpdatingLocation()
        case .authorizedWhenInUse:
            mapView.showsUserLocation = true
            grokUserLocation()
        @unknown default:
            break
        }
    }
    
    private func grokUserLocation() {
        if let location =
            locationManager.location?.coordinate {
            let region = MKCoordinateRegion.init(center: location, latitudinalMeters: userRadiusInMeters, longitudinalMeters: userRadiusInMeters)
            mapView.setRegion(region, animated: true)
        }
    }
    
    private func locationServicesCheck() {
        if CLLocationManager.locationServicesEnabled() {
            setupLocationServices()
            checkAuthStatus()
        } else {
            print ("Ok fine then ...")
        }
    }
}

extension ViewController {
    
    /*
     
     func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
         guard let location = locations.last else {return}
         let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
         let region = MKCoordinateRegion.init(center: center, latitudinalMeters: userRadiusInMeters, longitudinalMeters: userRadiusInMeters)
         mapView.setRegion(region, animated: true)
     }
     
     
     */
    
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        checkAuthStatus()
    }
}

