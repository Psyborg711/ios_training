//
//  DetailViewController.swift
//  pokedexV3
//
//  Created by Consultant on 3/7/22.
//

import UIKit
import CoreData

class DetailViewController: UIViewController{
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    @IBOutlet weak var pokemonImage: UIImageView!
    @IBOutlet weak var pokemonName: UILabel!

    @IBOutlet weak var pokemonIdentifier: UILabel!

    @IBOutlet weak var element: UILabel!

    @IBOutlet weak var movementsTableView: UITableView!

    @IBOutlet weak var abilitiesTableView: UITableView!
    
    @IBOutlet weak var favoriteIcon: UIButton!
    
    @IBOutlet weak var scrollImage: UIView!
    
    var movements = [Moves]()
    var abilities = [Abilities]()

    var pokemonData: PokemonData?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        scrollImage.layer.cornerRadius = 10

        movementsTableView.register(UITableViewCell.self, forCellReuseIdentifier: "moveCell")
        movementsTableView.delegate = self
        movementsTableView.dataSource = self

        abilitiesTableView.register(UITableViewCell.self, forCellReuseIdentifier: "abilityCell")
        abilitiesTableView.delegate = self
        abilitiesTableView.dataSource = self

        pokemonName.text = pokemonData?.name.capitalized

        let pokemonID: String = "No. \(String(pokemonData!.id))"

        pokemonIdentifier.text = pokemonID

        element.text = pokemonData?.types.first?.type.name.capitalized

        self.movements = pokemonData!.moves

        self.abilities = pokemonData!.abilities

        let spriteURL = pokemonData?.sprites.other.home.front_default
        do {
            let url = URL(string: spriteURL!)
            let data = try Data(contentsOf: url!)
            pokemonImage.image = UIImage(data: data)
        }
        catch{
            print(error)
        }
    }

    @IBAction func favoriteButtonTapped(_ sender: Any) {
        
        self.favoriteIcon.setImage(UIImage(systemName: "star.fill"), for: .normal)
        
        let newFav = Favorite(context: self.context)
        
        newFav.pokemonName = pokemonData?.name // NAME
        newFav.pokemonType = pokemonData?.types.first?.type.name // ELEMENT
        newFav.imageSprite = pokemonData?.sprites.front_default // IMAGE
        newFav.image3D = pokemonData?.sprites.other.home.front_default
        newFav.pokemonNumber = Int16(pokemonData!.id) // NUMBER        
        newFav.isFavorite = true
        
        // ABILITIES v
        var arrayAb = [Abilities]()
        for ab in pokemonData?.abilities ?? [] {
            arrayAb.append(ab)
        }

        var arrayAbString = [String]()
        for ability in arrayAb{
            arrayAbString.append(ability.ability.name)
        }

        newFav.abilities = arrayAbString
        // ABILITIES ^

        // MOVEMENTS v
        var arrayMv = [Moves]()
        for mv in pokemonData?.moves ?? []{
            arrayMv.append(mv)
        }
        var arrayMvString = [String]()
        for move in arrayMv{
            arrayMvString.append(move.move.name)
        }

        newFav.movements = arrayMvString
        // MOVEMENTS ^
        
        do{
            try self.context.save()
        }catch(let error){
            print(error.localizedDescription)
        }
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "load"), object: nil)
        
    }
}

extension DetailViewController: UITableViewDelegate, UITableViewDataSource{


    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int)->Int{

        if tableView == movementsTableView{
            return movements.count
        }

        return abilities.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        if tableView == movementsTableView{
            let cell = tableView.dequeueReusableCell(withIdentifier: "moveCell", for: indexPath)
            cell.textLabel!.text = movements[indexPath.row].move.name
            
            cell.imageView?.image = UIImage(systemName: "arrowtriangle.right")
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "abilityCell", for: indexPath)
            cell.textLabel!.text = abilities[indexPath.row].ability.name
            
            cell.imageView?.image = UIImage(systemName: "arrowtriangle.right")
            return cell

        }
    }
}
