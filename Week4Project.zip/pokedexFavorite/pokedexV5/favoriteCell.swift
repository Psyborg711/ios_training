//
//  favoriteCell.swift
//  pokedexV5
//
//  Created by Consultant on 3/13/22.
//

import UIKit

class favoriteCell: UITableViewCell{
    @IBOutlet weak var pokemonSprite: UIImageView!
    @IBOutlet weak var pokemonName: UILabel!
    @IBOutlet weak var pokemonElement: UILabel!
}
