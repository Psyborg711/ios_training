//
//  Favorite+CoreDataClass.swift
//  pokedexV5
//
//  Created by Consultant on 3/14/22.
//
//

import Foundation
import CoreData

@objc(Favorite)
public class Favorite: NSManagedObject {

}
