//
//  pokemonCell.swift
//  pokedexV3
//
//  Created by Consultant on 3/5/22.
//

import UIKit

class pokemonCell: UITableViewCell{
    
    @IBOutlet weak var pokemonSprite: UIImageView!
    @IBOutlet weak var pokemonName: UILabel!
    @IBOutlet weak var pokemonElement: UILabel!
}
