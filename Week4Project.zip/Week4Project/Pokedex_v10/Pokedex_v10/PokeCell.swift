//
//  PokeCell.swift
//  PokedexEVM
//
//  Created by Consultant on 3/4/22.
//

import UIKit

class PokeCell: UITableViewCell {

    @IBOutlet weak var pokeSprite: LazyImageView!
    @IBOutlet weak var pokeName: UILabel!
    @IBOutlet weak var pokeElement: LazyLoadLabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    

}
