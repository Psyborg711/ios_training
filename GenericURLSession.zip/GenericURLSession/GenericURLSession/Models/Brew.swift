//
//  Brew.swift
//  GenericURLSession
//
//  Created by Consultant on 3/3/22.
//

import Foundation
struct Brewery:Codable{
let name:String
let brewery_type:String
}
