//
//  User.swift
//  GenericURLSession
//
//  Created by Consultant on 3/3/22.
//

import Foundation

struct User: Codable{
    let name:String
    let email:String
}
