//
//  Post.swift
//  GenericURLSession
//
//  Created by Consultant on 3/3/22.
//

import Foundation
struct Post:Codable{
let title:String
let body:String
}
