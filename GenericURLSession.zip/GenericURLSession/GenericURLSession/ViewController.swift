//
//  ViewController.swift
//  GenericURLSession
//
//  Created by Consultant on 3/3/22.
//

import UIKit

class ViewController: UIViewController {
    var user = [User]()
    var post = [Post]()
    var Brew = [Brewery]()

    @IBOutlet weak var tableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchUser()
        setupDelegate()
        
        // Do any additional setup after loading the view.
    }
    
        func setupDelegate(){
            tableview.delegate = self
            tableview.dataSource = self
        }
    func fetchUser(){
     URLSession.shared.getRequest(url: APIEndpoints.Brewery, decoding: [Brewery].self ) { [weak self] result in
        switch result {
        case .success(let user):
            self?.Brew = user
            DispatchQueue.main.async {
                self?.tableview.reloadData()
                
            }
        case .failure(let error):
            print(error)
            
            }
        }
    }
}

   
    extension ViewController: UITableViewDelegate, UITableViewDataSource {
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return Brew.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableview.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        //    cell.textLabel?.text = user[indexPath.row].name.capitalized
         //   cell.detailTextLabel?.text = user[indexPath.row].email
          //  cell.textLabel?.text = post[indexPath.row].title.capitalized
      //      cell.detailTextLabel?.text = post[indexPath.row].body
            cell.textLabel?.text = Brew[indexPath.row].name.capitalized
            cell.detailTextLabel?.text = Brew[indexPath.row].brewery_type
            
            return cell
        }
    }

