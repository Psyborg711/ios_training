//
//  ExtensionUrlsSessionRequest.swift
//  GenericURLSession
//
//  Created by Consultant on 3/3/22.
//

import Foundation







extension URLSession{
    
    /* Here we are exteending urlsession by adding a geneeric networking cell funtion that does not need concern itself about classes. the only thing we care about is that wea re able to use the codable protocol with whatever type we pass into the parms in the func , We could alternativy make this of type T any meaning we could then do Json Serilalization
     For example:
     */
    
    func getRequest<T:Codable>(url:URL?, decoding:T.Type, completion: @escaping (Result<T, Error>)->()){
    
    guard let url = url else {
        completion(.failure(RequestErrors.badURL))
        return
    }
    let task = self.dataTask(with: url) { data, _, error in
        guard data != nil else {
            completion(.failure(RequestErrors.badData))
            return
        }
        if let error = error {
            completion(.failure(error))
            return
        }
        do{
            let jsonResult = try JSONDecoder().decode(decoding, from:data!)
            completion(.success(jsonResult))
            }
        catch {
            completion(.failure(error))
        }
    }
    task.resume()
}
}
