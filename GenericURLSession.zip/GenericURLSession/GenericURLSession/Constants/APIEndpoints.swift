//
//  APIEndpoints.swift
//  GenericURLSession
//
//  Created by Consultant on 3/3/22.
//

import Foundation
struct APIEndpoints{
    static let users = URL(string: "https://jsonplaceholder.typicode.com/users")
    static let posts = URL(string: "https://jsonplaceholder.typicode.com/posts")
    static let Brewery = URL(string: "https://api.openbrewerydb.org/breweries" )
}
