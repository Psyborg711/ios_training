//
//  FibViewController.swift
//  TestingPractice1
//
//  Created by Consultant on 3/15/22.
//

import UIKit

class FibViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var fibTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    
    var userInput: String{
        return (fibTextField.text)!
    }
    
    var fibNum: Int{
        return Int(userInput) ?? 0
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func fibBtn(_ sender: Any) {
        
        guard fibNum > 0 else { return }
        
        var fibonacci = [0,1]
        
        for i in 2...fibNum{
            fibonacci.append(i)
            fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2]
        }
        resultLabel.text = "\(fibonacci)"
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let allowedChar = "0123456789"
        let allowedCharSet = CharacterSet(charactersIn: allowedChar)
        let typedChar = CharacterSet(charactersIn: string)
        
        return allowedCharSet.isSuperset(of: typedChar)
    }

}
