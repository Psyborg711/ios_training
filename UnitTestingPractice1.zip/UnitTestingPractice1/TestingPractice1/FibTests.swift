//
//  fibValidation.swift
//  TestingPractice1
//
//  Created by Consultant on 3/17/22.
//

import Foundation
struct FibTests{
    
    func validateFibNo(_ fibNo:Int?) throws -> Int{
        
        guard let fibNumber = fibNo else { throw FibTestsError.invalidFibonacciEntry }
        guard fibNumber > 1 else { throw FibTestsError.FibonacciTooShort}
        guard fibNumber < 10 else { throw FibTestsError.FibonacciTooLong }
        return fibNumber
    }
}

enum FibTestsError: LocalizedError{
    case invalidFibonacciEntry
    case FibonacciTooShort
    case FibonacciTooLong
}
