//
//  ViewController.swift
//  TestingPractice1
//
//  Created by Consultant on 3/15/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    
    private let secondVC = "secondVC"
    private let validation: ValidationService
    private let dummyUser = [User(username: "admin", password: "password")]
    
    init(validation: ValidationService){
        self.validation = validation
        super.init(nibName: nil, bundle: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        passwordText.isSecureTextEntry = true
        // Do any additional setup after loading the view.
    }
    required init?(coder: NSCoder) {
        self.validation = ValidationService()
        super.init(coder: coder)
    }

    @IBAction func loginBtn(_ sender: Any) {
        
        do{
            let username = try validation.validateUserName(userText.text)
            let password = try validation.validatePassword(passwordText.text)
            
            if userText.text == username && passwordText.text == password{
                navigateNext()
            }
        } catch {
            
        }
    }
    
    private func navigateNext(){
        let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "secondVC") as! FibViewController
        self.navigationController?.pushViewController(homeVC, animated: true)
    }
    
}

