//
//  ValidationService.swift
//  TestingPractice1
//
//  Created by Consultant on 3/15/22.
//

import XCTest
@testable import TestingPractice1
class TestValidationServiceTest: XCTestCase {

    var validation: ValidationService!
    
    override func setUp(){
        super.setUp()
        validation = ValidationService()
    }
    
    override func tearDown(){
        super.tearDown()
        validation = nil
    }
    
    func testUsernameNil(){
        let expectedError = ValidationError.invalidEntry
        var error: ValidationError?
        
        XCTAssertThrowsError(try validation.validateUserName(nil)) { thrownError in error = thrownError as? ValidationError
        }
        XCTAssertEqual(expectedError, error)
    }
    
    func isValidUsername() throws{
        XCTAssertNoThrow(try validation.validateUserName("admin"))
    }
    
    func isUsernameShort() throws {
        let expectedError = ValidationError.usernameTooShort
        var error: ValidationError?
        
        XCTAssertThrowsError(try validation.validateUserName("xf")) {
            thrownError in
            error = thrownError as? ValidationError
        }
        XCTAssertEqual(expectedError, error)
    }
    
    func isUsernameLong() throws {
        let expectedError = ValidationError.usernameTooLong
        var error: ValidationError?
        let username = "ReallyLongUserName123"
        
        XCTAssertThrowsError(try validation.validateUserName(username)) {
            thrownError in
            error = thrownError as? ValidationError
        }
        XCTAssertEqual(expectedError, error)
    }
    
//    func isUsernameShort

}
