//
//  FibTests.swift
//  TestingPractice1Tests
//
//  Created by Consultant on 3/15/22.
//

import XCTest
@testable import TestingPractice1

class FibTest: XCTestCase {

    var validation: FibTests!
    
    override func setUp() {
        super.setUp()
        validation = FibTests()
    }
    
    override func tearDown() {
        super.tearDown()
        validation = nil
    }
    
    func testFibSeq(){
        let expectedReturn = [0, 1, 1, 2, 3]
        var fibonacci = [0, 1]
        
        for i in 2...4{
            fibonacci.append(i)
            fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2]
        }
        
        XCTAssertEqual(expectedReturn, fibonacci)
    }
    
    func testFibonacciNil() throws {
        
        let expectedError = FibTestsError.invalidFibonacciEntry
        var error: FibTestsError?
        
        XCTAssertThrowsError(try validation.validateFibNo(nil)){
            thrownError in
            error = thrownError as? FibTestsError
        }
        
        XCTAssertEqual(expectedError, error)
        
    }
    
    func testFibonacciEqualsZero() throws {
        let expectedError = FibTestsError.FibonacciTooShort
        var error: FibTestsError?
        
        XCTAssertThrowsError(try validation.validateFibNo(0)){
            thrownError in
            error = thrownError as? FibTestsError
        }
        XCTAssertEqual(expectedError, error)
    }
    
    func testFibonacciIsOutOfRanger() throws {
        let expectedError = FibTestsError.FibonacciTooLong
        var error: FibTestsError?
        
        XCTAssertThrowsError(try validation.validateFibNo(11)){
            thrownError in
            error = thrownError as? FibTestsError
        }
        
        XCTAssertEqual(expectedError, error)
    }
    
    func isValidFibonacciNumber() throws {
        XCTAssertNoThrow(try validation.validateFibNo(5))
    }
}
