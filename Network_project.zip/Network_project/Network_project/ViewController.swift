//
//  ViewController.swift
//  Network_project
//
//  Created by Consultant on 3/1/22.
//
// JSON Serialization example that dumps results into LOG

import UIKit

class ViewController: UIViewController {

        override func viewDidLoad() {
            super.viewDidLoad()
            fetchPosts()
            // Do any additional setup after loading the view.
        }
        
        // Make the request with URLSessionDataTask
        func fetchPosts(){
            /*
             
             */
            
            guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else { return }
            
            let session = URLSession.shared // Singleton object
            /*
             For basic requests, the URLSession class provides a shared singleton object that gives you a reasonable default behaviour for creating tasks. Use the shared session to fetch the contents of a URL to memoru with just a few lines of code
             */
            
            // MARK: URLSession
            /*
             The URLSession.shared is a reference to a shared URLSession instance that has no  configuration. It's more limited that a session that 's initialized with a URLSessionConfiguration object, but that's ok for now
             
             You can construct URLs and access their parts. For URLs that represent local files, you can also manipulate propertires of those files directly, such as changing the files lastt modification date. Finally, you can pass URLs to other APIs to retrieve the contents of those URLs . For example, you can use URLSession and its related clasess to access the contents of remote resources
             */
            
            let task = session.dataTask(with: url){
                data, response, error in
                if let error = error{
                    print("Error: \(error.localizedDescription)")
                } else {
                    /*
                     Here we're using the JsonObject(with: options) function of the JSONSerialization class to serialize the data to JSON. Essentially the data is read character by character and turned into a JSON object we can easily read and manipulate
                     
                     The optional binding with a failable try? can be used to temporaly silence any warnings from the jsonObject(...) The more proper way is to put our try into a do catch block.
                     */
                    do{
                    let jsonData =  try JSONSerialization.jsonObject(with: data!, options: [])
                    print("Response: \(String(describing: jsonData))")
                    }catch{
                        print(error)
                    }
                }
            }
            task.resume()
        }
    }
