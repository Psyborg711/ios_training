//
//  ViewController.swift
//  Week2Exam
//
//  Created by Consultant on 2/26/22.
//

import UIKit

class DescViewController: UIViewController {

    @IBOutlet weak var TestLabel: UILabel!
    @IBOutlet weak var TestTitleLabel: UILabel!
    @IBOutlet weak var AlbumCoverView: UIImageView!
    var descrpction = ""
    
    var song: Song?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("view from table cell initialized")
        //descript.text = descrpction
        // Do any additional setup after loading the view.
        
        changeLabels()
        changeCoverImage()
//        print(selectedAlbumCell)
        print("labels changed")
    }
    
    func changeLabels() {
        print("changing labels")
        TestTitleLabel.text = self.song?.name
        TestLabel.text = self.song?.desc
//        TestTitleLabel.text = songsList[selectedAlbumCell].name
//        TestLabel.text = songsList[selectedAlbumCell].desc
    }
    
    func changeCoverImage() {
        print("changing cover image")
                
        self.AlbumCoverView.image = self.song?.img
//        let albumCover = songsList[selectedAlbumCell].img
//        let albumCoverImageView
//
//        AlbumCoverView.addSubview(albumCoverImageView)
    }


}

