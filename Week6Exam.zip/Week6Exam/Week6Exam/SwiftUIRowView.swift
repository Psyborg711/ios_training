//
//  SwiftUIRowView.swift
//  Week6Exam
//
//  Created by Consultant on 4/2/22.
//

import SwiftUI

struct SwiftUIRowView: View {
    
    @Environment(\.colorScheme) var colorScheme
    
    let car: Car
    
    var body: some View {
        
        HStack {
            Image(car.imageURL)
                .resizable()
                .frame(width: 100, height: 100)
                .cornerRadius(10)
            
            VStack(alignment: .leading) {
                Text(car.name)
                Text(String(format: "%.1f€", car.price))
            }
            
            Spacer()
        }.background(colorScheme == .dark ? Color.black : Color.white)
    }
}



// struct SwiftUIRowView_Previews: PreviewProvider {
//     static var previews: some View {
//         SwiftUIRowView( car: Car)
//     }
// }



