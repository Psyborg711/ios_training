//
//  CarDetailView.swift
//  Week6Exam
//
//  Created by Consultant on 4/2/22.
//

import SwiftUI

struct CarDetailView: View {
    
    let car: Car
    
    @State private var zoomed: Bool = false
    
    var body: some View {
        
        VStack {
            Image(car.imageURL)
                .resizable()
                .aspectRatio(contentMode: self.zoomed ? .fill : .fit)
                .onTapGesture {
                    withAnimation {
                        self.zoomed.toggle()
                }
        }
            Text(car.name)
            Text(String(car.desc))
        }.navigationBarTitle(Text(car.name), displayMode: .inline)
    }
}

//struct CarDetailView_Previews: PreviewProvider {
//    static var previews: some View {
//        CarDetailView()
//    }
//}
