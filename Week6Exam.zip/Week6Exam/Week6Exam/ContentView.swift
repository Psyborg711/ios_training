//
//  ContentView.swift
//  Week6Exam
//
//  Created by Consultant on 4/1/22.
//

import SwiftUI

struct ContentView: View {
    
    let cars = Car.all()
    
    var body: some View {
        
        NavigationView {
            
            List(self.cars, id:\.name) { car in
                NavigationLink(destination: CarDetailView(car: car)) {
                    SwiftUIRowView(car: car)
                }
            }
            
            .navigationBarTitle("Luxury Cars")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
