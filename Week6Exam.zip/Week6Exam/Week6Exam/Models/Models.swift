//
//  Models.swift
//  Week6Exam
//
//  Created by Consultant on 4/2/22.
//

import Foundation

struct Car {
    let name: String
    let imageURL: String
    let price: Double
    let desc: String
}

extension Car {
    
    static func all() -> [Car] {
        
        return [
            Car(name: "Range Rover", imageURL: "pic1", price: 94400, desc: "The current, fourth-generation Range Rover is as revolutionary as any in the car’s history"),
            Car(name: "Mercedes-Benz S-Class", imageURL: "pic2", price: 80480, desc: "When Mercedes-Benz sets out to make a new S-Class, the brief is to make the best car in the world"),
            Car(name: "Audi E-tron Quattro", imageURL: "pic3", price: 58247, desc: "We’re now entering reasonably well-established times for the premium electric car"),
            Car(name: "Audi A8", imageURL: "pic4", price: 69115, desc: "The latest Audi A8 features some of the most advanced chassis"),
            Car(name: "Mercedes CLS", imageURL: "pic5", price: 71295, desc: "Whether Mercedes invented the modern hybrid vehicle bodystyle that, for a while, was amusingly dubbed the ‘coupoon’ "),
            Car(name: "BMW 7 Series", imageURL: "pic6", price: 86800, desc: "Since launch in 1977, the 7 Series has been in the shadow of the Mercedes S-Class, "),
            Car(name: "BMW X7", imageURL: "pic7", price: 87900, desc: "Don’t think of this as an enlarged X5, says Munich, but rather a jacked-up 7-Series "),
            Car(name: "Audi Q8", imageURL: "pic8", price: 69300, desc: "A great many modern car enthusiasts have taken against the modern luxury car buyers preference for the SUV"),
            Car(name: "Lexus LS", imageURL: "pic9", price: 75820, desc: "The LS has always been a niche choice in the UK"),
            Car(name: "Maserati Quattroporte", imageURL: "pic10", price: 96000, desc: "Our final ranking luxury class contender is a car with plenty of soul and brand-based exotic desirability"),
        ]
    }
}
