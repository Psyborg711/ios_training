//
//  Week6ExamApp.swift
//  Week6Exam
//
//  Created by Consultant on 4/1/22.
//

import SwiftUI

@main
struct Week6ExamApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
