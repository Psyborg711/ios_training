//
//  ViewController.swift
//  network2
//
//  Created by Consultant on 3/2/22.
//

import UIKit
/*
 codable is a type alias for the encodable and decodable protocols. when you use codable as a type or generic constraint, it matches any type that conforms to both protocols
 */
struct Dog: Decodable{
    let message: URL
    let status: String
}

class ViewController: UIViewController {

    @IBOutlet weak var mainImg: UIImageView!
    
    let urlString = "https://dog.ceo/api/breeds/image/random"
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func fetchImg(){
        guard let url = URL(string: urlString) else { print("bad url"); return }
        
        let session = URLSession.shared
        let task = session.dataTask(with: url) { data, response, error in
            guard let data = data else {
                print(error?.localizedDescription ?? "?No data avaiable")
                return
            }
            guard response != nil else{
                print(error?.localizedDescription ?? "no response returned")
                return
            }
            // if succesful this data now needs to be converted to Json. marking our API response struct Dog:codable means we will be able to use the Json decoder to decode the response object rather than serializing it with Json Serialization
            
            do{
                let jsonResponse = try JSONDecoder().decode(Dog.self, from: data)
                DispatchQueue.global().async {
                    //marking this try as failable
                    if let imageData = try? Data(contentsOf: jsonResponse.message){
                        //moving to main thread
                        DispatchQueue.main.async {
                            self.mainImg.image = UIImage(data: imageData)
                        }
                    }
                }
            }
            catch{
                print(error)
            }
            
        }
        task.resume()
    }
    
    @IBAction func mainBtn(_ sender: Any) {
        fetchImg()
    }
    
}

