//
//  NewsEndpoint.swift
//  NewsSwiftUI
//
//  Created by Admin on 3/27/22.
//

import Foundation
/*
 In order to make our code more reusable we are going to build our request using a protocol, this will allow us to add other requests that can reuse this blueprint for making a GET Request
 */
protocol APIBuilder {
    var urlRequest: URLRequest { get }
    var baseUrl: URL { get }
    var path: String { get }
}
//we can add cases as the app grows to get reviews, updates, video for example
enum NewsAPI {
    case getNews
}

extension NewsAPI:APIBuilder {
    
    var urlRequest: URLRequest {
        /*
         This function performs a file system operation to determine if the path component is a directory. If so, it will append a trailing /. If you know in advance that the path component is a directory or not, then use func appendingPathComponent
         */
        return URLRequest(url: self.baseUrl.appendingPathComponent(self.path))
    }
    
    var baseUrl: URL {
        switch self {
        case .getNews:
            return URL(string: "https://api.lil.software")!
        }
    }
    
    var path: String {
        return "/news"
    }
}
