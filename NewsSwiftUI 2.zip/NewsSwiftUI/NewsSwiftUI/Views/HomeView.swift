//
//  HomeView.swift
//  NewsSwiftUI
//
//  Created by Admin on 3/27/22.
//

import SwiftUI

struct HomeView: View {
    /*
     Create a state object in a View, App, or Scene by applying the @StateObject attribute to a property declaration and providing an initial value that conforms to the ObservableObject protocol
     https://www.hackingwithswift.com/quick-start/swiftui/what-is-the-stateobject-property-wrapper
     https://purple.telstra.com/blog/swiftui---state-vs--stateobject-vs--observedobject-vs--environme
     https://developer.apple.com/documentation/swiftui/stateobject
     */
  @StateObject var viewModel = NewsViewModelImpl(service: NewsServiceImpl())
    
    var body: some View {
        //when viewWillAppear triggers
        Group {
            switch viewModel.state {
            case .loading:
                ProgressView()
            case .failed(let error):
                ErrorView(error: error, handler: viewModel.getArticles)
            case .success(let articles):
                NavigationView {
                    List(articles) { item in
                        ArticleView(article: item)
                    }
                    .navigationTitle(Text("News"))
                }
            }
        }.onAppear(perform: viewModel.getArticles)
        
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
