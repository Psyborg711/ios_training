//
//  NewsSwiftUIApp.swift
//  NewsSwiftUI
//
//  Created by Admin on 3/27/22.
//

import SwiftUI

@main
struct NewsSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
