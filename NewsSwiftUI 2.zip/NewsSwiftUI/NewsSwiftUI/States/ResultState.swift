//
//  ResultState.swift
//  NewsSwiftUI
//
//  Created by Admin on 3/27/22.
//

import Foundation

enum ResultState {
    case loading
    case success(content: [Article])
    case failed(error: Error)
}
