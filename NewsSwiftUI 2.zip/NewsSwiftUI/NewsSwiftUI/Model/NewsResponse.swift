//
//  NewsResponse.swift
//  NewsSwiftUI
//
//  Created by Admin on 3/27/22.
//

import Foundation


struct NewsResponse: Decodable {
    let articles: [Article]
}

// MARK: - Article
/* in order to work with the SwiftUI equivalent of UIKit tableviews we will be using a list. Each element in a SwiftUI list must be unique, in order to have unique identfiers we are using UUID
 https://www.appypie.com/random-unique-identifier-uuid-swift-how-to
 https://nshipster.com/identifiable/
 https://developer.apple.com/documentation/swift/identifiable
https://www.hackingwithswift.com/books/ios-swiftui/working-with-identifiable-items-in-swiftui
*/
struct Article: Decodable, Identifiable {
    var id = UUID()
    let author: String?
    let url: String?
    let source, title, articleDescription: String?
    let image: String?
    let date: Date?

    enum CodingKeys: String, CodingKey {
        case author, url, source, title
        /*
         description is a reserved word in Swift so we cannot use it as a variable in our structure to decode the data and must therefore use codingkeys
         https://developer.apple.com/documentation/swift/customstringconvertible/1539130-description
         */
        case articleDescription = "description"
        case image, date
    }
}

extension Article {
    
    static var dummyData: Article {
        .init(author: "Adam Sweeting",
              url: "https://amp.theguardian.com/music/2022/mar/27/taylor-hawkins-obituary",
              source: "The Guardian",
              title: "Taylor Hawkins obituary - The Guardian",
              articleDescription: "Drummer, singer and songwriter with Foo Fighters who combined showmanship and humour with supreme technical skill",
              image: nil,
              date: Date())
    }
}
