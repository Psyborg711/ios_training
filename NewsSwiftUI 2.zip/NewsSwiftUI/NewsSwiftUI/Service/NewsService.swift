//
//  NewsService.swift
//  NewsSwiftUI
//
//  Created by Admin on 3/27/22.
//

import Foundation
import Combine

/*
 Dependency Injection:
 Dependency Injection is a software design pattern in which an object receives other instances that it depends on. It's a commonly used technique that allows reusing code, insert mocked data, and simplify testing
 https://www.appypie.com/dependency-injection-swift
 https://www.avanderlee.com/swift/dependency-injection/
 
 Combine publishers:
 A publisher delivers elements to one or more Subscriber instances. The subscriber's Input and Failure associated types must match the Output and Failure types declared by the publisher.
 https://heckj.github.io/swiftui-notes/#coreconcepts-publisher-subscriber
 https://heckj.github.io/swiftui-notes/#coreconcepts-publishers
 */

protocol NewsService {
    /*
     AnyPublisher:
     AnyPublisher is a concrete implementation of Publisher that has no significant properties of its own, and passes through elements and completion values from its upstream publisher.
     
     Use AnyPublisher to wrap a publisher whose type has details you don’t want to expose across API boundaries, such as different modules. Wrapping a Subject with AnyPublisher also prevents callers from accessing its send(_:) method. When you use type erasure this way, you can change the underlying publisher implementation over time without affecting existing clients.
     
     You can use Combine’s eraseToAnyPublisher() operator to wrap a publisher with AnyPublisher.
     https://developer.apple.com/documentation/combine/anypublisher
     */
    func request(from endpoint: NewsAPI) -> AnyPublisher<NewsResponse, APIError>
}

struct NewsServiceImpl: NewsService {
    func request(from endpoint: NewsAPI) -> AnyPublisher<NewsResponse, APIError> {
        return URLSession
            .shared
        //Returns a publisher that wraps a URL session data task for a given URL request.
            .dataTaskPublisher(for: endpoint.urlRequest)
        //Combine‘s flatMap(maxPublishers:_:) operator performs a similar function to the flatMap(_:) operator in the Swift standard library, but turns the elements from one kind of publisher into a new publisher that is sent to subscribers
        //You use the receive(on:options:) operator to receive results and completion on a specific scheduler, such as performing UI work on the main run loop
            .receive(on: DispatchQueue.main)
        // if Anything goes wrong map error to our existing error enumeration
            .mapError {_ in APIError.unknown }
            .flatMap { data, response -> AnyPublisher<NewsResponse, APIError> in
                guard let response = response as? HTTPURLResponse else {
                    return Fail(error: APIError.unknown).eraseToAnyPublisher()
                }
                
                if (200...299).contains(response.statusCode) {
                    let jsonDecoder = JSONDecoder()
                    //The strategy used when decoding dates from part of a JSON object.
                    jsonDecoder.dateDecodingStrategy = .iso8601
                    // A publisher that emits an output to each subscriber just once, and then finishes.
                    return Just(data)
                        .decode(type: NewsResponse.self, decoder: jsonDecoder)
                        .mapError { _ in APIError.decodingError }
                        .eraseToAnyPublisher()
                } else {
                    return Fail(error: APIError.errorCode(response.statusCode)).eraseToAnyPublisher()
                }
            }
        
        //Use eraseToAnyPublisher() to expose an instance of AnyPublisher to the downstream subscriber, rather than this publisher’s actual type. This form of type erasure preserves abstraction across API boundaries, such as different modules. When you expose your publishers as the AnyPublisher type, you can change the underlying implementation over time without affecting existing clients.
            .eraseToAnyPublisher()
    }
}
