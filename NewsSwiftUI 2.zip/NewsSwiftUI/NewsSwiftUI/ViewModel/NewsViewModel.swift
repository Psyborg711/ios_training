//
//  NewsViewModel.swift
//  NewsSwiftUI
//
//  Created by Admin on 3/27/22.
//

import Foundation
import Combine

/*
 Managing Views with the states in Combine:
 SwiftUI's built in state management system does a great a job in providing an out of the box data flow solution that alleviates a lot of the pain points associated with manually updating UI based on state changes.

 As your codebase grows and you find yourself leaning towards incorporating common architectural patterns, you'll likely come across the need to separate some state specific logic into a view model. Swift's Combine framework provides some great property wrappers to ease this transition via @PublishSubject and @ObservedObject.
 https://www.neilsmithdesign.com/dev/view-state-combine
 https://dev.to/obscured_pixels/managing-view-state-with-combine-p8k
 */

protocol NewsViewModel {
    func getArticles()
}
/*
 ObservableObject is a type of object with a publisher that emits before the object has changed.
 https://developer.apple.com/documentation/combine/observableobject
 https://www.swiftbysundell.com/articles/published-properties-in-swift/
 */
class NewsViewModelImpl: ObservableObject, NewsViewModel {
    
    private let service: NewsService
    /*
     Getters and setters for constants, variables, properties, and subscripts automatically receive the same access level as the constant, variable, property, or subscript they belong to.

     You can give a setter a lower access level than its corresponding getter, to restrict the read-write scope of that variable, property, or subscript. You assign a lower access level by writing fileprivate(set), private(set), or internal(set) before the var or subscript introducer.
     
     https://docs.swift.org/swift-book/LanguageGuide/AccessControl.html
     */
    private(set) var articles = [Article]()
    /*
     The purpose of cancellables in Combine, or rather the purpose of AnyCancellable in Combine is to associate the lifecycle of a Combine subscription to something other than the subscription completing.

     When we retain a cancellable in an instance of a view model, view controller, or any other object, the lifecycle of that subscription becomes connected to that of the owner (the retaining object) itself. Whenever the owner of the cancellable is deallocated, the subscription is torn down and all resources are freed up immediately.
     https://www.donnywals.com/what-exactly-is-a-combine-anycancellable/
     https://www.apeth.com/UnderstandingCombine/subscribers/subscribersanycancellable.html
     */
    private var cancellables = Set<AnyCancellable>()
    
    //setting default state to loading
    /*
     @Published is one of the most useful property wrappers in SwiftUI, allowing us to create observable objects that automatically announce when changes occur. SwiftUI will automatically monitor for such changes, and re-invoke the body property of any views that rely on the data.
     https://www.hackingwithswift.com/quick-start/swiftui/what-is-the-published-property-wrapper
     https://www.donnywals.com/publishing-property-changes-in-combine/
     https://developer.apple.com/documentation/combine/published
     */
    @Published private(set) var state: ResultState = .loading
    
    init(service: NewsService) {
        self.service = service
    }
    func getArticles() {
        
        self.state = .loading
        
        let cancellable = service.request(from: .getNews)
        /*
         This method creates the subscriber and immediately requests an unlimited number of values, prior to returning the subscriber. The return value should be held, otherwise the stream will be canceled.
         https://medium.com/swlh/sinks-and-completion-handlers-in-swift-combine-d97e89e5b7f
         https://developer.apple.com/documentation/combine/publisher/sink(receivecompletion:receivevalue:)
         */
            .sink { result in
                switch result {
                case .finished:
                    // return articles
                    self.state = .success(content: self.articles)
                    
                case .failure(let error):
                    // return error
                    self.state = .failed(error: error)
                }
            } receiveValue: { response in
                self.articles = response.articles
            }
        self.cancellables.insert(cancellable)
    }
}
